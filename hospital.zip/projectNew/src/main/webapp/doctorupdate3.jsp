<%@page import="java.sql.Connection"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.SQLException"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>update student</title>
<link rel="stylesheet" type="text/css" href="patientupdate.css">
</head>
<body>

<%
String name = request.getParameter("name");
	try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded!");
			Connection con1 = DriverManager.
					getConnection("jdbc:mysql://localhost:3306/hospital"
							,"root","root");
			System.out.println("Connection Created!");
			String qry = "select * from doctor where name=?";
			PreparedStatement pr1 = con1.prepareStatement(qry);
			pr1.setString(1, name);
			ResultSet rs = pr1.executeQuery();	
			response.getWriter().append("<h1>Update Data</h1>");
			response.getWriter().append("<html>");
			
			response.getWriter().append("<form action='doctorupdate2.jsp' method=''><table border='2px'>");
			while(rs.next())
			{	
				response.getWriter().append("<tr>");
				
				response.getWriter().append("<td>name</td>");
				response.getWriter().append("<td><input type='text' name='name'"
						+ " value='"+ rs.getString(1)+"' required></td>");
				response.getWriter().append("</tr>");
				
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>date of birth</td>");
				response.getWriter().append("<td><input type='date' name='dob'"
						+ " value='"+ rs.getString(2)+"' required></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>Age</td>");
				response.getWriter().append("<td><input type='number' name='age'"
						+ " value='"+ rs.getString(3)+"' required></td>");
			response.getWriter().append("</tr>");
			response.getWriter().append("<tr>");
			response.getWriter().append("<td>Gender</td>");
			response.getWriter().append("<td><input type='text' name='gender'"
					+ " value='"+ rs.getString(4)+"' required></td>");
		response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>Address</td>");
				response.getWriter().append("<td><input type='text' name='address'"
						+ " value='"+ rs.getString(5)+"' required></td>");
				
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>City</td>");
				response.getWriter().append("<td><input type='text' name='city'"
						+ " value='"+ rs.getString(6)+"' required></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>Degree</td>");
				response.getWriter().append("<td><input type='text' name='degree'"
						+ " value='"+ rs.getString(7)+"' required></td>");
				
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>Specialization</td>");
				response.getWriter().append("<td><input type='text' name='specialization'"
						+ " value='"+ rs.getString(8)+"' required></td>");
				response.getWriter().append("</tr>");
				
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>Experience</td>");
				response.getWriter().append("<td><input type='number' name='experience'"
						+ " value='"+ rs.getString(9)+"' required></td>");
				response.getWriter().append("</tr>");

				response.getWriter().append("<tr>");
				response.getWriter().append("<td>mobile number</td>");
				response.getWriter().append("<td><input type='number' name='phone'"
						+ " value='"+ rs.getString(10)+"' required></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>Email</td>");
				response.getWriter().append("<td><input type='email' name='email'"
						+ " value='"+ rs.getString(11)+"' required></td>");
			response.getWriter().append("</tr>");
			
			response.getWriter().append("<tr>");
			response.getWriter().append("<td>username</td>");
			response.getWriter().append("<td><input type='text' name='username'"
					+ " value='"+ rs.getString(12)+"' readonly></td>");
			response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>password</td>");
			response.getWriter().append("<td><input type='password' name='password'"
						+ " value='"+ rs.getString(13)+"' required></td>");
				response.getWriter().append("</tr>");
				
				response.getWriter().append("<tr>");
				response.getWriter().append("<td><input type='submit' value='submit' ></td>");
				response.getWriter().append("</tr>");
				
			}
			response.getWriter().append("</table></form></html>");
			//response.getWriter().append(""+pr1);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}

	%>
</body>
</html>