<%@page import="java.sql.Connection"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.SQLException"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Update Student</title>
<link rel="stylesheet" type="text/css" href="Showall.css">
</head>
<body>

<%
String username = request.getParameter("username");
	try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded!");
			Connection con1 = DriverManager.
					getConnection("jdbc:mysql://localhost:3306/school"
							,"root","root");
			System.out.println("Connection Created!");
			String qry = "select * from student where username=?";
			PreparedStatement pr1 = con1.prepareStatement(qry);
			pr1.setString(1, username);
			ResultSet rs = pr1.executeQuery();	
			response.getWriter().append("<h1>Update Data</h1>");
			response.getWriter().append("<html>");
			
			response.getWriter().append("<form action='Updatestudent2.jsp' method=''><table border='2px'>");
			while(rs.next())
			{	
				response.getWriter().append("<tr>");
				
				response.getWriter().append("<td>name</td>");
				response.getWriter().append("<td><input type='text' name='name'"
						+ " value='"+ rs.getString(1)+"' required></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>fathername</td>");
				response.getWriter().append("<td><input type='text' name='fathername'"
						+ " value='"+ rs.getString(2)+"' required></td>");
			response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>mothername</td>");
				response.getWriter().append("<td><input type='text' name='mothername'"
						+ " value='"+ rs.getString(3)+"' required></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>date of birth</td>");
				response.getWriter().append("<td><input type='date' name='date'"
						+ " value='"+ rs.getString(4)+"' required></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>class</td>");
				response.getWriter().append("<td><input type='text' name='classs'"
						+ " value='"+ rs.getString(5)+"' required></td>");
			response.getWriter().append("</tr>");
			response.getWriter().append("<tr>");
			response.getWriter().append("<td>Fees</td>");
			response.getWriter().append("<td><input type='text' name='fees'"
					+ " value='"+ rs.getString(6)+"' readonly></td>");
		response.getWriter().append("</tr>");
		
		response.getWriter().append("<tr>");
		response.getWriter().append("<td>Paid fees</td>");
		response.getWriter().append("<td><input type='text' name='paidfees'"
				+ " value='"+ rs.getString(7)+"' readonly></td>");
	response.getWriter().append("</tr>");
	
	response.getWriter().append("<tr>");
	response.getWriter().append("<td>Remaining fees</td>");
	response.getWriter().append("<td><input type='text' name='remainfees'"
			+ " value='"+ rs.getString(8)+"' readonly></td>");
response.getWriter().append("</tr>");
		
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>age</td>");
				response.getWriter().append("<td><input type='number' name='age'"
						+ " value='"+ rs.getString(9)+"' required></td>");
				
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>gender</td>");
				response.getWriter().append("<td><input type='text' name='gender'"
						+ " value='"+ rs.getString(10)+"' required></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>session</td>");
				response.getWriter().append("<td><input type='number' name='sessions'"
						+ " value='"+ rs.getString(11)+"' required></td>");
				
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>email</td>");
				response.getWriter().append("<td><input type='email' name='email'"
						+ " value='"+ rs.getString(12)+"' required></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>city</td>");
				response.getWriter().append("<td><input type='text' name='city'"
						+ " value='"+ rs.getString(13)+"' required></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>pincode</td>");
				response.getWriter().append("<td><input type='number' name='pincode'"
						+ " value='"+ rs.getString(14)+"' required></td>");
			response.getWriter().append("</tr>");
			response.getWriter().append("<tr>");
			response.getWriter().append("<td>address</td>");
			response.getWriter().append("<td><input type='text' name='address'"
					+ " value='"+ rs.getString(15)+"' required></td>");
			response.getWriter().append("</tr>");
			response.getWriter().append("<tr>");
			response.getWriter().append("<td>mobilenumber</td>");
			response.getWriter().append("<td><input type='number' name='mobilenumber'"
					+ " value='"+ rs.getString(16)+"' required></td>");
			response.getWriter().append("</tr>");
			response.getWriter().append("<tr>");
			response.getWriter().append("<td>username</td>");
			response.getWriter().append("<td><input type='text' name='username'"
					+ " value='"+ rs.getString(17)+"' readonly></td>");
			response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>password</td>");
			response.getWriter().append("<td><input type='password' name='password'"
						+ " value='"+ rs.getString(18)+"' required></td>");
				response.getWriter().append("</tr>");
				
				response.getWriter().append("<tr>");
				response.getWriter().append("<td><input type='submit' value='submit' ></td>");
				response.getWriter().append("</tr>");
				
			}
			response.getWriter().append("</table></form></html>");
			//response.getWriter().append(""+pr1);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}

	%>
</body>
</html>