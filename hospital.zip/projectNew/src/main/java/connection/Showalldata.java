package connection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Showalldata
 */
@WebServlet("/Showalldata")
public class Showalldata extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Showalldata() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub\
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded!");
			Connection con1 = DriverManager.
					getConnection("jdbc:mysql://localhost:3306/program"
							,"root","root");
			System.out.println("Connection Created!");
			String qry = "select * from person";
			PreparedStatement pr1 = con1.prepareStatement(qry);
			ResultSet rs = pr1.executeQuery();
			response.getWriter().append("<h1>All Data</h1>");
			response.getWriter().append("<table border='2px'><tr><th>Sno.</th><th>Name</th>");
			response.getWriter().append("<th>Email</th><th>city</th>");
			response.getWriter().append("<th>Contact</th><th>Date</th></tr>");
			int i=1;
			while(rs.next())
			{
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>"+ i +"</td>");
				response.getWriter().append("<td>"+ rs.getString(1)+"</td>");
				response.getWriter().append("<td>"+ rs.getString(2)+"</td>");
				response.getWriter().append("<td>"+ rs.getString(3)+"</td>");
				response.getWriter().append("<td>"+ rs.getString(4)+"</td>");
				response.getWriter().append("<td>"+ rs.getString(5)+"</td>");
				response.getWriter().append("<td><a href='Update1?email="+rs.getString(2)+"'>Update</a></td>");
				response.getWriter().append("<td><a href='Delete1?email="+rs.getString(2)+"'>Delete</a></td>");
				response.getWriter().append("</tr>");
				i++;
			}
			response.getWriter().append("</table>");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
