<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@page import="java.sql.SQLException"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Show All Student</title>
<link rel="stylesheet" type="text/css" href="Showall.css">
</head>
<body>

  <section class="header">
	<div class="navbar">
		 <%
  try {
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver loaded!");
		Connection con1 = DriverManager.
				getConnection("jdbc:mysql://localhost:3306/school"
						,"root","root");
		System.out.println("Connection Created!");
		String qry = "select * from student";
		PreparedStatement pr1 = con1.prepareStatement(qry);
		ResultSet rs = pr1.executeQuery();
		response.getWriter().append("<h1>All Student's Name</h1>");
		response.getWriter().append("<table border='2px'><tr><th>Sno.</th><th>Roll no.</th><th>Name</th><th>Father's Name</th><th>Mother's Name</th>");
		response.getWriter().append("<th>Date Of Birth</th><th>Class</th>");
		response.getWriter().append("<th>Age</th><th>gender</th><th>Session</th><th>E-mail</th><th>City</th><th>Pincode</th>");
		response.getWriter().append("<th>Address</th></tr>");
		int i=1;
		int j=101;
		while(rs.next())
		{
			response.getWriter().append("<tr>");
			response.getWriter().append("<td>"+ i +"</td>");
			response.getWriter().append("<td>"+ j +"</td>");
			response.getWriter().append("<td>"+ rs.getString(1)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(2)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(3)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(4)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(5)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(6)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(7)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(8)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(9)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(10)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(11)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(12)+"</td>");
			
			
			
			
			response.getWriter().append("</tr>");
			i++;
			j++;
		}
		response.getWriter().append("</table>");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}  
  %>
	</div>
  </section>
</body>
</html>