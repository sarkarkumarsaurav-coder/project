<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
<link rel="stylesheet" type="text/css" href="student1.css">
</head>
<body>
       <section class="header">
       	<h1>Student's Information</h1>
       	<div class="navbar">
       		<ul>
       			<li><a href="Signuppage1.html">Registration</a></li>
       			<li><a href="loginstudent.html">Login</a></li>
       			<li><a href="Showall.jsp">Show All Student's Name</a></li>
       		</ul>
       	</div>
       </section>
</body>
</html>