<%@page import="java.sql.SQLException"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Register Faculty</title>
<link rel="stylesheet" type="text/css" href="facultyregister.css">
</head>
<body>

    <%
    String name = request.getParameter("name");
	String date= request.getParameter("date");
	String age = request.getParameter("age");
	String gender = request.getParameter("gender");
	String year = request.getParameter("year");
	String email = request.getParameter("email");
	String city = request.getParameter("city");
	String pincode = request.getParameter("pincode");
	String address = request.getParameter("address");
	String number = request.getParameter("number");
	String salary = request.getParameter("salary");
	String username = request.getParameter("username");
	String password = request.getParameter("password");
	
	try {
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver loaded!");
		Connection con1 = DriverManager.
				getConnection("jdbc:mysql://localhost:3306/school"
						,"root","root");
		System.out.println("Connection Created!");
		String qry = "insert into faculty values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pr1 = con1.prepareStatement(qry);
		pr1.setString(1, name);
		pr1.setString(2, date);
		pr1.setString(3, age);
    	pr1.setString(4, gender);
		pr1.setString(5, year);
		pr1.setString(6, email);
		pr1.setString(7, city);
		pr1.setString(8, pincode);
		pr1.setString(9, address);
		pr1.setString(10, number);
		pr1.setString(11, salary);
		pr1.setString(12, username);
		pr1.setString(13, password);
				
		int i=pr1.executeUpdate();
	    if(i>0)
	    {
	    	response.getWriter().append("<h1>Data Inserted Successfully!!!! </h1><a href='faculty.jsp'>Go to Home Page</a>");
	   }
	    else
	    {
	    	response.getWriter().append	("<h1>Data not inserted!!!!!! <h1>");
	    }
		//response.getWriter().append("<h1>Data Inserted Successfully!!!! </h1><a href='student.jsp'>Go to Index page</a>");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    %>
</body>
</html>