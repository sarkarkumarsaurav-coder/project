package connection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Signup
 */
@WebServlet("/Signup")
public class Signup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Signup() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("name");
		String email= request.getParameter("email");
		String city = request.getParameter("city");
		String contact = request.getParameter("contact");
		String date = request.getParameter("date");
		String password = request.getParameter("password");
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded!");
			Connection con1 = DriverManager.
					getConnection("jdbc:mysql://localhost:3306/program"
							,"root","root");
			System.out.println("Connection Created!");
			String qry = "insert into person values(?,?,?,?,?,?)";
			PreparedStatement pr1 = con1.prepareStatement(qry);
			pr1.setString(1, name);
			pr1.setString(2, email);
			pr1.setString(3, city);
			pr1.setString(4, contact);
			pr1.setString(5, date);
			pr1.setString(6, password);
		    int i=pr1.executeUpdate();
		    if(i>0)
		    {
		    	System.out.print("<h1>Data inserted successfully <h1>");
		    }
		    else
		    {
		    	System.out.print("<h1>Data not inserted!!!!!! <h1>");
		    }
			response.getWriter().append("<h1>Data Inserted Successfully!!!! </h1><a href='index.html'>Go to Index page</a>");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
