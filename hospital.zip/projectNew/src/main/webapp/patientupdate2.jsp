<%@page import="java.sql.SQLException"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>update student</title>
<link rel="stylesheet" type="text/css" href="patientupdate.css">
</head>
<body>

<%
String name = request.getParameter("name");
String dob = request.getParameter("dob");
String age = request.getParameter("age");
String gender = request.getParameter("gender");
String address = request.getParameter("address");
String city = request.getParameter("city");
String weight = request.getParameter("weight");
String diseases = request.getParameter("diseases");
String phone = request.getParameter("phone");
String email = request.getParameter("email");
String fees = request.getParameter("fees");
String appointmentdate = request.getParameter("appointmentdate");
String appointmenttime= request.getParameter("appointmenttime");
String appointdoctor= request.getParameter("appointdoctor");
String username = request.getParameter("username");
String password = request.getParameter("password");


try {
	Class.forName("com.mysql.jdbc.Driver");
	System.out.println("Driver loaded!");
	Connection con1 = DriverManager.
			getConnection("jdbc:mysql://localhost:3306/hospital"
					,"root","root");
	System.out.println("Connection Created!");
    String qry = "update patient set dob=?,age=?,gender=?,address=?,city=?,weight=?,diseases=?,phone=?,email=?,fees=?,appointmentdate=?,appointmenttime=?,appointdoctor=?,username=?,password=? where name=?";
	PreparedStatement pr1 = con1.prepareStatement(qry);
	
	pr1.setString(1, dob);
	pr1.setString(2, age);
	pr1.setString(3, gender);
	pr1.setString(4, address);
	pr1.setString(5, city);
	pr1.setString(6, weight );
	pr1.setString(7, diseases );
	pr1.setString(8, phone);
	pr1.setString(9, email );
	pr1.setString(10, fees);
	pr1.setString(11, appointmentdate);
	pr1.setString(12, appointmenttime);
	pr1.setString(13, appointdoctor);
	pr1.setString(14, username );
	pr1.setString(15, password );
	pr1.setString(16, name);
	
	pr1.executeUpdate();
	//response.getWriter().append(""+con1);
	response.sendRedirect("showallpatient.jsp");
	
} catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
%>
</body>
</html>