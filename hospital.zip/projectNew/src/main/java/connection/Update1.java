package connection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Update1
 */
@WebServlet("/Update1")
public class Update1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Update1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String email = request.getParameter("email");
		//response.getWriter().append(email);
	try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded!");
			Connection con1 = DriverManager.
					getConnection("jdbc:mysql://localhost:3306/program"
							,"root","root");
			System.out.println("Connection Created!");
			String qry = "select * from person where email=?";
			PreparedStatement pr1 = con1.prepareStatement(qry);
			pr1.setString(1, email);
			ResultSet rs = pr1.executeQuery();
			response.getWriter().append("<html><h1>Update Data</h1>");
			
			response.getWriter().append("<form action='Update2' method='post'><table border='2px'>");
			while(rs.next())
			{	
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>name</td>");
				response.getWriter().append("<td><input type='text' name='name'"
						+ " value='"+ rs.getString(1)+"' required></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>email</td>");
				response.getWriter().append("<td><input type='text' name='email'"
						+ " value='"+ rs.getString(2)+"' readonly></td>");
			response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>city</td>");
				response.getWriter().append("<td><input type='text' name='city'"
						+ " value='"+ rs.getString(3)+"' required></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>contact</td>");
				response.getWriter().append("<td><input type='number' name='contact'"
						+ " value='"+ rs.getString(4)+"' required></td>");
			response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>date</td>");
			response.getWriter().append("<td><input type='date' name='date'"
						+ " value='"+ rs.getString(5)+"' required></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>password</td>");
				response.getWriter().append("<td><input type='text' name='password'"
						+ " value='"+ rs.getString(6)+"' required></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td><input type='submit' value='submit'></td>");
				response.getWriter().append("</tr>");
			}
			response.getWriter().append("</table></form></html>");
			//response.getWriter().append(""+pr1);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}

	}

}
