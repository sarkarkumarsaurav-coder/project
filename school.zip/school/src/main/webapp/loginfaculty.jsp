<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@page import="java.sql.SQLException"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>login faculty</title>
<link rel="stylesheet" type="text/css" href="loginfaculty.css">
</head>
<body>

    <%
    String username = request.getParameter("username");
	String password = request.getParameter("password");
	
	try {
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver loaded!");
		Connection con1 = DriverManager.
				getConnection("jdbc:mysql://localhost:3306/school"
						,"root","root");
		System.out.println("Connection Created!");
		String qry = "select * from faculty where username=? and password=?";
		PreparedStatement pr1 = con1.prepareStatement(qry);
		pr1.setString(1, username);
		pr1.setString(2, password);
		ResultSet rs = pr1.executeQuery();
		//response.getWriter().append(""+pr1);
	if(rs.next())
		{
			response.getWriter().append("<h1>Login Successfully!!!! </h1><a href='faculty.jsp'>Go to Index page</a>");
			response.sendRedirect("Updatefaculty1.jsp?username="+username);
		}
		else
		{
			response.getWriter().append("<h1>Invalid ID and PASSWORD!!!! </h1><a href='loginfaculty1.html'>Go to login page</a>");
		}
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    %>
</body>
</html>