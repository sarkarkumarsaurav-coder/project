<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@page import="java.sql.SQLException"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>update </title>
<link rel="stylesheet" type="text/css" href="user.css">
</head>
<body>

<%
String diseases = request.getParameter("diseases");

	try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded!");
			Connection con1 = DriverManager.
					getConnection("jdbc:mysql://localhost:3306/hospital"
							,"root","root");
			System.out.println("Connection Created!");
			String qry = "select * from patient where diseases=? ";
			PreparedStatement pr1 = con1.prepareStatement(qry);
			pr1.setString(1, diseases);
		
			
			ResultSet rs = pr1.executeQuery();	
			
			//response.getWriter().append("<h1>Login successfully</h1>");
			response.getWriter().append("<html>");
			
			response.getWriter().append("<form action='' method=''><table border='2px'>");
			while(rs.next())
			{	response.getWriter().append("<h1>Patient Detail</h1>");
				response.getWriter().append("<tr>");
				
				response.getWriter().append("<td>name</td>");
				response.getWriter().append("<td><input type='text' name='name'"
						+ " value='"+ rs.getString(1)+"' readonly></td>");
				response.getWriter().append("</tr>");
				

				response.getWriter().append("<tr>");
				response.getWriter().append("<td>date</td>");
				response.getWriter().append("<td><input type='date' name='dob'"
						+ " value='"+ rs.getString(2)+"' readonly></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>Age</td>");
				response.getWriter().append("<td><input type='number' name='age'"
						+ " value='"+ rs.getString(3)+"' readonly></td>");
			response.getWriter().append("</tr>");
			response.getWriter().append("<tr>");
			response.getWriter().append("<td>Gender</td>");
			response.getWriter().append("<td><input type='text' name='gender'"
					+ " value='"+ rs.getString(4)+"' readonly></td>");
		response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>Address</td>");
				response.getWriter().append("<td><input type='text' name='address'"
						+ " value='"+ rs.getString(5)+"' readonly></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>City</td>");
				response.getWriter().append("<td><input type='text' name='city'"
						+ " value='"+ rs.getString(6)+"' readonly></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>Weight</td>");
				response.getWriter().append("<td><input type='text' name='weight'"
						+ " value='"+ rs.getString(7)+"' readonly></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>Diseases</td>");
				response.getWriter().append("<td><input type='text' name='diseases'"
						+ " value='"+ rs.getString(8)+"' readonly></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>Fess</td>");
				response.getWriter().append("<td><input type='number' name='fees'"
						+ " value='"+ rs.getString(11)+"' readonly></td>");
				response.getWriter().append("</tr>");
				
			response.getWriter().append("<tr>");
			response.getWriter().append("<td>mobilenumber</td>");
			response.getWriter().append("<td><input type='number' name='phone'"
					+ " value='"+ rs.getString(9)+"' readonly></td>");
			response.getWriter().append("</tr>");
			
			response.getWriter().append("<tr>");
			response.getWriter().append("<td>Email</td>");
			response.getWriter().append("<td><input type='email' name='email'"
					+ " value='"+ rs.getString(10)+"' readonly></td>");
			response.getWriter().append("</tr>");

			response.getWriter().append("<tr>");
			response.getWriter().append("<td>Allowted doctor</td>");
			response.getWriter().append("<td><input type='text' name='appointdoctor'"
					+ " value='"+ rs.getString(14)+"' readonly></td>");
			response.getWriter().append("</tr>");
				
				
				response.getWriter().append("<tr>");
				//response.getWriter().append("<td><a href='selectpatient.html'>search your patient</a></td>");
	
				//response.getWriter().append("<td><a href='patientdelete.jsp?name="+rs.getString(1)+"'>Delete</a></td>");
			
	}
			response.getWriter().append("</table></form></html>");
			//response.getWriter().append(""+pr1);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}

	%>
</body>
</html>