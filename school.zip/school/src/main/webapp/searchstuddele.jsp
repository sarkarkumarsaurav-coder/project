<%@page import="java.sql.SQLException"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Delete student</title>
<link rel="stylesheet" type="text/css" href="admindetails.css">
</head>
<body>
<%
String name = request.getParameter("name");
try {
	Class.forName("com.mysql.jdbc.Driver");
	System.out.println("Driver loaded!");
	Connection con1 = DriverManager.
			getConnection("jdbc:mysql://localhost:3306/school"
					,"root","root");
	System.out.println("Connection Created!");
	String qry = "delete from student where name=?";
	PreparedStatement ps1 = con1.prepareStatement(qry);
	ps1.setString(1, name);
	ps1.executeUpdate();
	//response.getWriter().append(""+con1);
	response.getWriter().append("<h1>Data Deleted!!!! </h1><a href='searchstudent.html'>Go to Search Again Page</a>");
	//response.sendRedirect("Showall.jsp");
	
} catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

%>
</body>
</html>