<%@page import="java.sql.SQLException"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>update faculty</title>
<link rel="stylesheet" type="text/css" href="admindetails.css">
</head>
<body>

<%
String name = request.getParameter("name");
String date = request.getParameter("date");
String age = request.getParameter("age");
String gender = request.getParameter("gender");
String year = request.getParameter("year");
String email = request.getParameter("email");
String city = request.getParameter("city");
String pincode = request.getParameter("pincode");
String address = request.getParameter("address");
String number = request.getParameter("number");
String salary = request.getParameter("salary");
String username = request.getParameter("username");
String password = request.getParameter("password");





try {
	Class.forName("com.mysql.jdbc.Driver");
	System.out.println("Driver loaded!");
	Connection con1 = DriverManager.
			getConnection("jdbc:mysql://localhost:3306/school"
					,"root","root");
	System.out.println("Connection Created!");
    String qry = "update faculty set date=?,age=?,gender=?,year=?,email=?,city=?,pincode=?,address=?,number=?,salary=?,username=?, password=? where name=?";
	PreparedStatement pr1 = con1.prepareStatement(qry);
	
	pr1.setString(1, date);
	pr1.setString(2, age);
	pr1.setString(3, gender);
	pr1.setString(4, year);
	pr1.setString(5, email );
	pr1.setString(6, city );
	pr1.setString(7, pincode );
	pr1.setString(8, address );
	pr1.setString(9, number );
	pr1.setString(10, salary );
	pr1.setString(11, username );
	pr1.setString(12, password );
	pr1.setString(13, name);
	pr1.executeUpdate();
	//response.getWriter().append(""+pr1);
	response.sendRedirect("adminfacdetail.jsp");
	
} catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
%>
</body>
</html>