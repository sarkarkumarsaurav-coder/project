<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@page import="java.sql.SQLException"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Search faculty</title>
<link rel="stylesheet" type="text/css" href="loginfaculty.css">
</head>
<body>

    <%
    String name = request.getParameter("name");
		
	try {
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver loaded!");
		Connection con1 = DriverManager.
				getConnection("jdbc:mysql://localhost:3306/school"
						,"root","root");
		System.out.println("Connection Created!");
		String qry = "select * from faculty where name=?";
		PreparedStatement pr1 = con1.prepareStatement(qry);
		pr1.setString(1, name);
		ResultSet rs = pr1.executeQuery();
		//response.getWriter().append(""+pr1);
	if(rs.next())
		{
			//response.getWriter().append("<h1>Login Successfully!!!! </h1><a href='faculty.jsp'>Go to Index page</a>");
			response.sendRedirect("searchfacupd1.jsp?name="+name);
		}
		else
		{
			response.getWriter().append("<h1>Faculty Not Found!!!! </h1><a href='searchfaculty.html'>Go To Faculty Search Page</a>");
		}
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    %>
</body>
</html>