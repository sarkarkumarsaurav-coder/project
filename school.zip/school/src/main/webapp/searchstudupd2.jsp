<%@page import="java.sql.SQLException"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>update student</title>
<link rel="stylesheet" type="text/css" href="searchstudent.css">
</head>
<body>

<%
String name = request.getParameter("name");
String fathername = request.getParameter("fathername");
String mothername = request.getParameter("mothername");
String date = request.getParameter("date");
String age = request.getParameter("age");
String classs = request.getParameter("classs");
String fees = request.getParameter("fees");
String paidfees = request.getParameter("paidfees");
String remainfees = request.getParameter("remainfees");
String gender = request.getParameter("gender");
String sessions = request.getParameter("sessions");
String email = request.getParameter("email");
String city = request.getParameter("city");
String pincode = request.getParameter("pincode");
String address = request.getParameter("address");
String mobilenumber = request.getParameter("mobilenumber");
String username = request.getParameter("username");
String password = request.getParameter("password");


try {
	Class.forName("com.mysql.jdbc.Driver");
	System.out.println("Driver loaded!");
	Connection con1 = DriverManager.
			getConnection("jdbc:mysql://localhost:3306/school"
					,"root","root");
	System.out.println("Connection Created!");
    String qry = "update student set fathername=?,mothername=?,date=?,classs=?,fees=?,paidfees=?,remainfees=?,age=?,gender=?,sessions=?,email=?,city=?,pincode=?,address=?,mobilenumber=?,username=?,password=? where name=?";
	PreparedStatement pr1 = con1.prepareStatement(qry);
	
	pr1.setString(1, fathername);
	pr1.setString(2, mothername);
	pr1.setString(3, date);
	pr1.setString(4, classs);
	pr1.setString(5, fees );
	pr1.setString(6, paidfees );
	pr1.setString(7, remainfees );
	pr1.setString(8, age );
	pr1.setString(9, gender);
	pr1.setString(10, sessions );
	pr1.setString(11, email );
	pr1.setString(12, city );
	pr1.setString(13, pincode );
	pr1.setString(14, address );
	pr1.setString(15, mobilenumber );
	pr1.setString(16, username );
	pr1.setString(17, password );
	pr1.setString(18, name);
	
	pr1.executeUpdate();
	//response.getWriter().append("data updated!!!!"+con1);
	
	response.sendRedirect("adminstudetail.jsp");
	
} catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
%>
</body>
</html>