<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Faculty</title>
<link rel="stylesheet" type="text/css" href="Faculty.css">
</head>
<body>
     
       <section class="header">
           <h1>Our Fcaulties</h1>
       	<div class="navbar">
       		<ul>
       			<li><a href="facultyregister.html">Faculty Registration</a></li>
       			<li><a href="Loginfaculty1.html">Login Faculty</a></li>
       			<li><a href="allfaculty.jsp">Show All Faculties Name</a></li>
       		</ul>
       	</div>
       </section>
</body>
</html>