<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>National Public School</title>
<link rel="stylesheet" type="text/css" href="school.css">
</head>
<body>



<section class="header">
		<div class="logo"><img src="logo.jpeg" alt="logo"></div>
		<h1>National Public School</h1>

		<div class="nav">
		
		<ul>
			<li><a href="school.jsp">Home</a></li>
			<li><a href="#mission">Our mission</a></li>
			<li><a href="fessstructure.html" >Fees stucture</a></li>
			<li><a href="timetable.html" >Time Table</a></li>
			<li><a href="#abou" >About</a></li>
		</ul>
	</div>
	
  <div class="navbar">
  	<ul>
        <li><a href="admin.html">Admin </a></li>    	
  		<li><a href="student1.jsp">Student portal</a></li>
  		<li><a href="faculty.jsp">Faculty</a></li>
  	</ul>
  </div>
<div class="text-box">
	<h2>Preparing Young Mind For Success</h2>
	<h3>Addmision Open -  Pre Primary To 12th</h3>
</div>
</section>
<section class="school" id="abou">
	<h1>National Public school,Indore</h1>
	<p>The National Public School is affiliated to Central Board of Secondary Education No. 10365.
	 This National Public School was conceived and created by an educationist & Visionary Dr. Ramesh Badlani and
	  nurtured by Ms. Vijaylaxmi Khatwani. Education is a dynamic force ever evolving, so it was decided by the founders,
	   to induct educationists who could place the school among the premier or preeminent or foremost institution of the country.</p>
</section>
<section class="staff">
	<h1>A COMMITTED FACULTY AND STAFF</h1>
	<p>The school has an extremely qualified and committed faculty, In fact, the recruited staff has had exposure to
	 international educational system in India and abroad. They are trained in the activity based learning and teaching methods.

In addition, lesson planning, classroom performance and contribution to co-curricular activities are under the constant
 supervision of the Principal herself who believes that the quality of teaching and learning must be of the highest order,
  day-by-day, hour-by- hour, lesson-by-lesson. The school is also committed to staff development through a wide range of
   on-going in-service programmes and workshops, which cover not only academics and pedagogy but also areas such as psychological 
   counselling, personality development and career counselling.</p>
</section>
<section class="parents">
	<h1>BRIDGING WITH PARENTS</h1>
	<p>We understand that the active participation of parents in the activities of the school is essential if we are to 
	flourish as a school community. We would like the their experience to be a positive one.

Parents are kept in formed of all the school events through circulars, student link-book. They follow their child’s
 progress through regular and detailed school reports and one to one interaction with the concerned staff during PTM
  (Parent Teacher Meet). The school also welcomes parents to visit the school to discuss matters of concern with the 
  block In-charge / Principal.
In this way we ensure that everyone contributes to the outstanding development of students.</p>
</section>
<section class="idea" >
	<h1>OUR EMBLEM</h1>
	<p>IDEAS – INNOVATION-IMPRESSIONS OUR EMBLEM
The emblem of the school displays an open book, flanked by horses on either side and an emerging pen.
 the open book and pen are symbolic of knowledge and articulate expression, symbolizing the power of the mind.
The horses represent power, agility and strength- the physical attributes to compliment it.
 (Our philosophy is to generate Ideas, which translate into innovation in the field of education, 
 resulting in everlasting Impressions on the psyche of young students.)</p>
</section>
<section class="mission" id="mission">
	<h1>OUR PHILOSOPHY & MISSION</h1>
	<p>Education is our mission. We believe in excellence and we aim, aspire and achieve it in all spheres of
	 its requirement. Our desire is to create sensitive human beings & responsible citizens. We do not stop at 
	 academics- we groom our students to grow into confident & self-sufficient individuals-The hallmarks of true 
	 public school breeding. We have incorporated modern concepts, amenities & systems to create a progressive and
	  vibrant institution, Compatible or well matched with only the best in the country.</p>
</section>
<section class="objective">
	<h1>OUR OBJECTIVES</h1>
	<p>To give shape to our mission we have set out the following objectives.</p>
	<div>
     <ul>
 <li>Serve as a bridge between home & school.</li><br>
 <li>Develop logical reasoning & a scientific temper, to keep pace with th technological world of today.</li><br>
 <li>Establish a partnership with the parents of the children.</li><br>
 <li>To develop an independent & creative thought process.</li><br>
 <li>Grooming self assured individuals, who are both confident & expressive, focussing on all round growth-physical,
  mental, moral & aesthetic.</li><br>
 <li>All plans, programs and systems to be student centered, so as to develop in them a national as well as global 
 perspective.</li><br>
 <li>Reflect CBSE vision & its adopted goals.</li>
 </div>

</ul>
</section>
</body>
</html>