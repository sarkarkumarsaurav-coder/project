<%@page import="java.sql.SQLException"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Registration</title>
<link rel="stylesheet" type="text/css" href="Signuppage.css">
</head>
<body>

      
      <% 
        String name = request.getParameter("name");
		String fathername= request.getParameter("fathername");
		String mothername = request.getParameter("mothername");
		String date = request.getParameter("date");
		String classs = request.getParameter("classs");
		String fees = request.getParameter("fees");
		String paidfees = request.getParameter("paidfees");
		String remainfees = request.getParameter("remainfees");
		String age = request.getParameter("age");
		String gender = request.getParameter("gender");
		String sessions = request.getParameter("sessions");
		String email = request.getParameter("email");
		String city = request.getParameter("city");
		String pincode = request.getParameter("pincode");
		String address = request.getParameter("address");
		String mobilenumber = request.getParameter("mobilenumber");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		
		
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded!");
			Connection con1 = DriverManager.
					getConnection("jdbc:mysql://localhost:3306/school"
							,"root","root");
			System.out.println("Connection Created!");
			String qry = "insert into student values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement pr1 = con1.prepareStatement(qry);
			pr1.setString(1, name);
			pr1.setString(2, fathername);
			pr1.setString(3, mothername);
			pr1.setString(4, date);
			pr1.setString(5, classs);
			pr1.setString(6, fees);
			pr1.setString(7, paidfees);
			pr1.setString(8, remainfees);
			pr1.setString(9, age);
			pr1.setString(10, gender);
			pr1.setString(11, sessions);
			pr1.setString(12, email);
			pr1.setString(13, city);
			pr1.setString(14,pincode);
			pr1.setString(15,address);
			pr1.setString(16,mobilenumber);
			pr1.setString(17,username);
			pr1.setString(18,password);
			
			
			
			
		    int i=pr1.executeUpdate();
		    if(i>0)
		    {
		    	response.getWriter().append("<h1>Data Inserted Successfully!!!! </h1><a href='student1.jsp'>Go to Home Page</a>");
		   }
		    else
		    {
		    	response.getWriter().append("<h1>Data not inserted!!!!!! </h1>");
		    }
			//response.getWriter().append("<h1>Data Inserted Successfully!!!! </h1><a href='student.jsp'>Go to Index page</a>");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		%>
</body>
</html>