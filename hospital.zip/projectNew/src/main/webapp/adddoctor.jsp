<%@page import="java.sql.SQLException"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Register patient</title>
<link rel="stylesheet" type="text/css" href="">
</head>
<body style="background-image:url(bk1.jpg);">

    <%
    String name = request.getParameter("name");
	String dob= request.getParameter("dob");
	String age = request.getParameter("age");
	String gender = request.getParameter("gender");
	String address = request.getParameter("address");
	String city = request.getParameter("city");
	String degree = request.getParameter("degree");
	String specialization = request.getParameter("specialization");
	String experience = request.getParameter("experience");
	String phone = request.getParameter("phone");
	String email = request.getParameter("email");
	String username = request.getParameter("username");
	String password = request.getParameter("password");
	
	try {
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver loaded!");
		Connection con1 = DriverManager.
				getConnection("jdbc:mysql://localhost:3306/hospital"
						,"root","root");
		System.out.println("Connection Created!");
		String qry = "insert into doctor values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pr1 = con1.prepareStatement(qry);
		pr1.setString(1, name);
		pr1.setString(2, dob);
		pr1.setString(3, age);
    	pr1.setString(4, gender);
    	pr1.setString(5, address);
    	pr1.setString(6, city);
		pr1.setString(7, degree);
		pr1.setString(8, specialization);
		pr1.setString(9, experience);
		pr1.setString(10, phone);
		pr1.setString(11, email);
		pr1.setString(12, username);
		pr1.setString(13, password);
				
		int i=pr1.executeUpdate();
	    if(i>0)
	    {
	    	response.getWriter().append("<h1>Doctor Added Successfully!!!! </h1><a href='adddoctor.html'>Go to appointment page</a>");
	   }
	    else
	    {
	    	response.getWriter().append	("<h1>Adding failled !!!!!! <h1>");
	    }
		//response.getWriter().append("<h1>Data Inserted Successfully!!!! </h1><a href='student.jsp'>Go to Index page</a>");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    %>
</body>
</html>