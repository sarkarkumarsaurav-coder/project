<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@page import="java.sql.SQLException"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Admin faculty Details</title>
<link rel="stylesheet" type="text/css" href="admindetails.css">
</head>
<body>
<%
 try {
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver loaded!");
		Connection con1 = DriverManager.
				getConnection("jdbc:mysql://localhost:3306/school"
						,"root","root");
		System.out.println("Connection Created!");
		String qry = "select * from faculty";
		PreparedStatement pr1 = con1.prepareStatement(qry);
		ResultSet rs = pr1.executeQuery();
		response.getWriter().append("<h1>Our All Faculties Name</h1>");
		response.getWriter().append("<table border='2px'><tr><th>Sno.</th><th>Name</th><th>Date Of Birth</th><th>Age</th>");
		response.getWriter().append("<th>Gender</th><th>Year</th><th>E-mail</th><th>City</th><th>Pincode</th>");
		response.getWriter().append("<th>Address</th><th>Mobile number</th><th>Salary</th><th>Username</th>");
		response.getWriter().append("<th>password</th></tr>");
		int i=1;
		while(rs.next())
		{
			response.getWriter().append("<tr>");
			response.getWriter().append("<td>"+ i +"</td>");
			response.getWriter().append("<td>"+ rs.getString(1)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(2)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(3)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(4)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(5)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(6)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(7)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(8)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(9)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(10)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(11)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(12)+"</td>");
			response.getWriter().append("<td>"+ rs.getString(13)+"</td>");
			
			
			response.getWriter().append("</tr>");
			i++;
		}
		response.getWriter().append("</table>");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
 %> 
</body>
</html>