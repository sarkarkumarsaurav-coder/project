<%@page import="java.sql.SQLException"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Register patient</title>
<link rel="stylesheet" type="text/css" href="">
</head>
<body style="background-image:url(bk1.jpg);">

    <%
    String name = request.getParameter("name");
	String dob= request.getParameter("dob");
	String age = request.getParameter("age");
	String gender = request.getParameter("gender");
	String address = request.getParameter("address");
	String city = request.getParameter("city");
	String weight = request.getParameter("weight");
	String diseases = request.getParameter("diseases");
	String phone = request.getParameter("phone");
	String email = request.getParameter("email");
	String fees = request.getParameter("fees");
	String appointmentdate = request.getParameter("appointmentdate");
	String appointmenttime = request.getParameter("appointmenttime");
	String appointdoctor = request.getParameter("appointdoctor");
	String username = request.getParameter("username");
	String password = request.getParameter("password");
	String emergency = request.getParameter("emergency");
	
	try {
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver loaded!");
		Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","root");
		System.out.println("Connection Created!");
		String qry = "insert into patient values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pr1 = con1.prepareStatement(qry);
		pr1.setString(1, name);
		pr1.setString(2, dob);
		pr1.setString(3, age);
    	pr1.setString(4, gender);
    	pr1.setString(5, address);
    	pr1.setString(6, city);
		pr1.setString(7, weight);
		pr1.setString(8, diseases);
		pr1.setString(9, phone);
		pr1.setString(10, email);
		pr1.setString(11, fees);
		pr1.setString(12, appointmentdate);
		pr1.setString(13, appointmenttime);
		pr1.setString(14, appointdoctor);
		pr1.setString(15, username);
		pr1.setString(16, password);
		pr1.setString(17, emergency);
				
		int i=pr1.executeUpdate();
	    if(i>0)
	    {
	    	response.getWriter().append("<h1>Appointment booked Successfully!!!! </h1><a href='appoint.html'>Go to appointment page</a>");
	   }
	    else
	    {
	    	response.getWriter().append	("<h1>Appointment booking failled !!!!!! <h1>");
	    }
		//response.getWriter().append("<h1>Data Inserted Successfully!!!! </h1><a href='student.jsp'>Go to Index page</a>");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    %>
</body>
</html>