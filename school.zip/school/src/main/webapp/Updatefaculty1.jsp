<%@page import="java.sql.SQLException"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Update</title>
<link rel="stylesheet" type="text/css" href="Allfaculty.css">
</head>
<body>
<%
String username = request.getParameter("username");
	try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded!");
			Connection con1 = DriverManager.
					getConnection("jdbc:mysql://localhost:3306/school"
							,"root","root");
			System.out.println("Connection Created!");
			String qry = "select * from faculty where username=?";
			PreparedStatement pr1 = con1.prepareStatement(qry);
			pr1.setString(1, username);
			ResultSet rs = pr1.executeQuery();	
			response.getWriter().append("<h1>Login successfully</h1>");
			response.getWriter().append("<html>");
			
			response.getWriter().append("<form action='' method=''><table border='2px'>");
			while(rs.next())
			{	
				response.getWriter().append("<tr>");
				
				response.getWriter().append("<td>name</td>");
				response.getWriter().append("<td><input type='text' name='name'"
						+ " value='"+ rs.getString(1)+"' readonly></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>date of birth</td>");
				response.getWriter().append("<td><input type='date' name='date'"
						+ " value='"+ rs.getString(2)+"' readonly></td>");
			response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>age</td>");
				response.getWriter().append("<td><input type='number' name='age'"
						+ " value='"+ rs.getString(3)+"' readonly></td>");

				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>gender</td>");
				response.getWriter().append("<td><input type='text' name='gender'"
						+ " value='"+ rs.getString(4)+"' readonly></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>year</td>");
				response.getWriter().append("<td><input type='number' name='year'"
						+ " value='"+ rs.getString(5)+"' readonly></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>email</td>");
				response.getWriter().append("<td><input type='email' name='email'"
						+ " value='"+ rs.getString(6)+"' readonly></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>city</td>");
				response.getWriter().append("<td><input type='text' name='city'"
						+ " value='"+ rs.getString(7)+"' readonly></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>pincode</td>");
				response.getWriter().append("<td><input type='number' name='pincode'"
						+ " value='"+ rs.getString(8)+"' readonly></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>address</td>");
				response.getWriter().append("<td><input type='text' name='address'"
						+ " value='"+ rs.getString(9)+"' readonly></td>");
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>mobilenumber</td>");
			response.getWriter().append("<td><input type='number' name='number'"
						+ " value='"+ rs.getString(10)+"' readonly></td>");
				response.getWriter().append("</tr>");
				
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>salary</td>");
				response.getWriter().append("<td><input type='number' name='salary'"
						+ " value='"+ rs.getString(11)+"' readonly></td>");
				response.getWriter().append("</tr>");
				
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>username</td>");
				response.getWriter().append("<td><input type='username' name='username'"
						+ " value='"+ rs.getString(12)+"' readonly></td>");
			response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td>password</td>");
				response.getWriter().append("<td><input type='number' name='password'"
						+ " value='"+ rs.getString(13)+"' readonly></td>");
			response.getWriter().append("</tr>");
				
				
				response.getWriter().append("</tr>");
				response.getWriter().append("<tr>");
				response.getWriter().append("<td><a href='Updatefaculty3.jsp?username="+rs.getString(12)+"'>Update</a></td>");
	
				//response.getWriter().append("<td><a href='Deletefaculty.jsp?username="+rs.getString(12)+"'>Delete</a></td>");
				
			}
			response.getWriter().append("</table></form></html>");
			//response.getWriter().append(""+pr1);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}

	%>
</body>
</html>